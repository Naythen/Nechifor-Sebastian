/*Exercitiul 5:
    %: Sa se lucreze sortarea transformand for -> while      */
#include<iostream>
using namespace std;
int main()
{
    int i,j,n,alesul,V[100];
    cout<<"n=";
    cin>>n;
    cout<<"Numerele dorite sunt : "<<endl;
    i = 0;
    while(i < n)
    {
        cout << "V[" << i+1 << "] = ";
        cin>>V[i];
        i++;
    }
    i = 1;
    while(i <= n-1)
    {
        alesul=V[i];
        j=i-1;
        while((alesul<V[j])&&(j>=0))
        {
            V[j+1]=V[j];
            j=j-1;
        }
        V[j+1]=alesul;
        i++;
    }
    i = 0;
    cout<<"Numerele au fost sortate :"<<endl;
    while(i < n)
    {
        cout<<V[i]<<" ";
        i++;
    }
    return 0;
}

/*Exercitiul 3:
    3: Sa se lucreze sortarea ordonandu-se descrescator     */
#include<iostream>
using namespace std;
int main()
{
    int i,j,n,alesul,V[100];
    cout<<"n=";
    cin>>n;
    cout<<"Numerele dorite sunt : "<<endl;
    for(i=0;i<n;i++)
    {
        cout << "V[" << i+1 << "] = ";
        cin>>V[i];
    }
    for(i=1;i<=n-1;i++)
    {
        alesul=V[i];
        j=i-1;
        while((alesul>V[j])&&(j>=0))
        {
            V[j+1]=V[j];
            j=j-1;
        }
        V[j+1]=alesul;
    }
    cout<<"Numerele introduse au fost sortate "<<endl;
    for(i=0;i<n;i++)
    {
        cout<<V[i]<<" ";
    }
    return 0;
}
